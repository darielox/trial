import hashlib
def hash_password(password):
    # Hash the given password using SHA-256 algorithm
    hash_object = hashlib.sha256(password.encode())
    return hash_object.hexdigest()
