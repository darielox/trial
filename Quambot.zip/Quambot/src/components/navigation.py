import customtkinter
from PIL import Image, ImageTk
class NavigationBar(customtkinter.CTkFrame):
    def __init__(self, parent, history, on_back=None, on_forward=None):
        super().__init__(parent)

        self.history = history
        self._on_back = on_back
        #self._on_forward = on_forward

        img2 = customtkinter.CTkImage(Image.open("assets/images/135210286.png").resize((70, 70), Image.ANTIALIAS))
        # create the back button
        self.back_button = customtkinter.CTkButton(self, text="Back", image=img2, width=20, height=20, fg_color='red', command=self._on_back_button_click)
        self.back_button.pack(side="left")

        '''''
        # create the forward button
        self.forward_button = customtkinter.CTkButton(self, text="Forward", command=self._on_forward_button_click)
        self.forward_button.pack(side="left")
        '''''
    def _on_back_button_click(self):
        if self.history:
            current_screen = self.history.pop()
            current_screen.pack_forget()

            if self.history:
                previous_screen = self.history[-1]
                previous_screen.pack()

                if len(self.history) >= 2:
                    self._on_back = lambda: self.history[-2].pack_forget()
                else:
                    self._on_back = None

                self._on_forward = lambda: current_screen.pack_forget()

        if self._on_back:
            self._on_back()

    '''''
    def _on_forward_button_click(self):
        if self._on_forward and self.history:
            next_screen = self.history.pop(0)
            next_screen.pack()
            self._on_back = lambda: self.history.insert(0, next_screen)
        else:
            print("Cannot go forward.")
    '''''


    def add_to_history(self, screen):
        # Check if the current page is already in the history
        if self.history and self.history[-1] == screen:
            return

        # Remove any duplicates of the current page in the history
        self.history = [p for p in self.history if p != screen]

        # Add the current screen to the history
        self.history.append(screen)

        # Update the back and forward button callbacks
        if len(self.history) >= 2:
            self._on_back = lambda: self.history[-2].pack_forget()
            self._on_forward = None
        else:
            self._on_back = None
            self._on_forward = None
