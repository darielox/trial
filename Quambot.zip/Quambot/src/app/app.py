from tkinter import messagebox
from Quambot.src.screens.login import LoginScreen
from Quambot.src.databases.database import Database
from Quambot.src.screens.dashboard import Dashboard
from Quambot.src.components.navigation import NavigationBar
from Quambot.src.screens.registration_legal import PatientTable, RegistrationForm
import customtkinter


class App(customtkinter.CTk):
    def __init__(self, master=None):
        super().__init__()

        self.master = master
        self.dashboard = None
        self.main_app = None
        self.patients_data = []
        self.title("QuanBox")
        self.geometry("1300x700")
        self._on_forward = None
        self._on_back = None

        self.history = []
        self.navigation_bar = NavigationBar(self, self.history)
        self.database = Database()  # create an instance of the Database class
        self.on_back_callback = lambda: None
        self.on_forward_callback = lambda: None
        self.login_screen = LoginScreen(self, self.on_login)
        self.login_screen.pack()
        self.protocol("WM_DELETE_WINDOW", self.on_exit)

    def view_records(self):
        # add the dashboard to the history
        self.history.append(self.dashboard)

        # hide the dashboard
        self.dashboard.pack_forget()

        self.patients_data = self.database.get_all_patients()
        patient_table = PatientTable(self)
        # create and show the patient table
        patient_table.view_patients()

        # set the back button callback
        self.navigation_bar._on_back = lambda: self.show_dashboard()

        # set the forward button callback
        self.navigation_bar._on_forward = lambda: patient_table.pack_forget()

        # pack the navigation bar and patient table
        self.navigation_bar.pack(side="top", fill="x")
        patient_table.pack()

    def show_register_patient_form(self):
        # hide the dashboard
        self.dashboard.pack_forget()

        # add the dashboard to the history
        self.history.append(self.dashboard)

        # create the registration form
        register_patient_form = RegistrationForm(self, on_submit=self.save_patient_data)

        # add the form to the history
        self.history.append(register_patient_form)

        # set the back button callback
        self.navigation_bar._on_back = lambda: self.show_dashboard()

        # set the forward button callback
        self.navigation_bar._on_forward = lambda: register_patient_form.pack_forget()

        # pack the navigation bar and registration form
        self.navigation_bar.pack(side="top", fill="x")
        register_patient_form.pack()

    def save_patient_data(self, patient_data):
        self.database.insert_patient(patient_data)
        # Update the patient view button with the new patient information
        patient_id = patient_data['patient_id']
        view_button = self.dashboard.patient_buttons[patient_id]['view_button']
        view_button.config(text=f"View Patient {patient_id}\n{patient_data['name']}")

    def on_login(self):
        self.login_screen.pack_forget()  # hide the login screen

        # enable back and forward buttons when not on login screen
        self._on_forward = lambda: None
        self._on_back = lambda: None
        self.show_dashboard()

    def logout(self):
        self.patients_data = []
        self.history = []
        self.dashboard.pack_forget()
        self.login_screen.destroy()
        self.login_screen = LoginScreen(self, on_login=self.on_login)
        self.login_screen.pack(fill="both", expand=True)

    def show_dashboard(self, size=None):
        if not self.dashboard:
            # create the dashboard
            self.dashboard = Dashboard(self, self.show_register_patient_form, self.view_records, self.logout)

        # clear the history
        self.history = []

        # remove all widgets except the dashboard and navigation bar
        for widget in self.winfo_children():
            if widget not in [self.dashboard, self.navigation_bar]:
                widget.destroy()

        # set the back button callback
        self.navigation_bar._on_back = lambda: self.show_dashboard(size)

        # pack the navigation bar
        self.navigation_bar.pack(side="top", fill="x")

        # pack the dashboard, with its previous size if available
        if size:
            self.dashboard.width = size[0]
            self.dashboard.height = size[1]
        else:
            self.dashboard.width = 1200
            self.dashboard.height = 500
        self.dashboard.pack(side="bottom", fill='both', expand=True)

    def on_exit(self):
        if messagebox.askokcancel("Quit", "Do you want to quit?"):
            self.destroy()