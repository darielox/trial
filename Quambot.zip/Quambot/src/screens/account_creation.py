from tkinter import messagebox
from Quambot.src.components.utils import hash_password
from Quambot.src.databases.userdatabase import UserDatabase
import customtkinter


class AccountCreationScreen(customtkinter.CTkToplevel):
    def __init__(self, parent, conn, on_login):
        super().__init__(parent)  # Call the __init__ method of the parent class (tk.Frame)
        self.title("Create Account")
        self.conn = conn
        self.on_login = on_login

        self.geometry("500x400")

        self.username_label = customtkinter.CTkLabel(self, text="Username:")
        self.username_label.pack()

        self.username_entry = customtkinter.CTkEntry(self)
        self.username_entry.pack()

        self.password_label = customtkinter.CTkLabel(self, text="Password:")
        self.password_label.pack()

        self.password_entry = customtkinter.CTkEntry(self, show="*")
        self.password_entry.pack()

        self.admin_password_label = customtkinter.CTkLabel(self, text="Admin Password:")
        self.admin_password_label.pack()

        self.admin_password_entry = customtkinter.CTkEntry(self, show="*")
        self.admin_password_entry.pack()

        self.create_account_button = customtkinter.CTkButton(self, text="Create Account", command=self.create_account)
        self.create_account_button.pack()

    def create_account(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        admin_password = self.admin_password_entry.get()

        # Check if admin password is correct (replace 'admin_password_here' with your actual admin password)
        if admin_password != "1111":
            messagebox.showerror("Admin Password Error", "Incorrect admin password.")
            return

        # Initialize the UserDatabase class to interact with the database
        user_db = UserDatabase(self.conn)

        # Check if the username already exists in the database
        if user_db.get_user_by_username(username):
            messagebox.showerror("Account Creation Error",
                                 "Username already exists. Please choose a different username.")
            return

        # Hash the password before storing it in the database
        hashed_password = hash_password(password)

        # Insert the new user's information into the database
        user_db.insert_user(username, hashed_password)

        # After successful account creation, close the account creation window and show a message
        messagebox.showinfo("Account Creation", "Account created successfully!")
        self.destroy()
        self.on_login()
