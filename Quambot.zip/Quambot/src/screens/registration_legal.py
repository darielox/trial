from tkinter import *
import tkinter as tk
from tkinter import messagebox
from Quambot.src.databases.database import Database
import customtkinter

class RegistrationForm(customtkinter.CTkFrame):
    def __init__(self, parent, on_submit=None):
        super().__init__(parent)

        self.parent = parent
        self.on_submit = on_submit

        self.name_var = tk.StringVar()
        self.age_var = tk.StringVar()
        self.gender_var = tk.StringVar(value="Male")
        self.address_var = tk.StringVar()

        # create the form widgets here...
        self.first_name_label = customtkinter.CTkLabel(self, text="Name:")
        self.first_name_label.pack()

        self.first_name_entry = customtkinter.CTkEntry(self, textvariable=self.name_var)
        self.first_name_entry.pack()

        self.age_label = customtkinter.CTkLabel(self, text="Age:")
        self.age_label.pack()

        self.age_entry = customtkinter.CTkEntry(self, textvariable=self.age_var)
        self.age_entry.pack()

        self.gender_label = customtkinter.CTkLabel(self, text="Gender:")
        self.gender_label.pack()

        self.gender_var = tk.StringVar(value="Male")
        self.gender_male_radio = tk.Radiobutton(self, text="Male", variable=self.gender_var, value="Male")
        self.gender_male_radio.pack()

        self.gender_female_radio = tk.Radiobutton(self, text="Female", variable=self.gender_var, value="Female")
        self.gender_female_radio.pack()

        self.address_label = customtkinter.CTkLabel(self, text="Address")
        self.address_label.pack()

        self.address_entry = customtkinter.CTkEntry(self, textvariable=self.address_var)
        self.address_entry.pack()

        self.submit_button = customtkinter.CTkButton(self, text="Submit", command=self.submit_form)
        self.submit_button.pack()

    def submit_form(self):
        name = self.name_var.get()
        age = self.age_var.get()
        gender = self.gender_var.get()
        address = self.address_var.get()

        # check if all fields are filled out
        if not all([name, age, gender, address]):
            messagebox.showerror("Error", "All fields are required!")
            return

        # check if age is a valid integer
        try:
            age = int(age)
        except ValueError:
            messagebox.showerror("Error", "Age must be a number!")
            return

        # create patient data dictionary
        patient_data = {
            "name": name,
            "age": age,
            "gender": gender,
            "address": address
        }

        # insert patient data into database
        db = Database()
        db.insert_patient(patient_data)

        # show success message
        messagebox.showinfo("Success", "Patient registration successful!")

        # destroy the form fields
        self.name_var.set('')
        self.age_var.set('')
        self.gender_var.set('Male')
        self.address_var.set('')


class PatientTable(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.patients = []
        self.parent = parent
        self.database = Database()
        self.txt_patients = None
        self.name_var = StringVar()
        self.age_var = StringVar()
        self.id_var = StringVar()
        self.gender_var = StringVar(value="Male")
        self.address_var = StringVar()
        self.selected_patient_id = None

    def view_patients(self):

        patients = self.database.get_all_patients()

        # create a new window to display patient data
        view_frame = Frame(self.parent)
        view_frame.pack()

        # create a label to display patient data
        lbl_patients = Label(view_frame, text="Patient Data", font=("Arial", 14))
        lbl_patients.pack(pady=10)

        # create a text widget to display patient data
        txt_patients = Text(view_frame, font=("Arial", 12))
        txt_patients.pack(padx=10, pady=10)

        # insert patient data into the text widget
        for patient in patients:
            txt_patients.insert(END, f"ID: {patient['id']}\n")
            txt_patients.insert(END, f"Name: {patient['name']}\n")
            txt_patients.insert(END, f"Age: {patient['age']}\n")
            txt_patients.insert(END, f"Gender: {patient['gender']}\n")
            txt_patients.insert(END, f"Address: {patient['address']}\n")
            txt_patients.insert(END, "\n")

        # create a button to delete a patient
        btn_delete_patient = Button(view_frame, text="Delete Patient", command=self.delete_patient)
        btn_delete_patient.pack(pady=10)

        # create a button to update a patient
        btn_update_patient = Button(view_frame, text="Update Patient", command=self.update_patient)
        btn_update_patient.pack(pady=10)

    def delete_patient(self):
        # create a new window to delete patient data
        delete_window = Toplevel(self.parent)
        delete_window.title("Delete Patient")
        delete_window.geometry("300x100")

        # create the form widgets here...
        id_label = Label(delete_window, text="ID:")
        id_label.pack()

        id_entry = Entry(delete_window)
        id_entry.pack()

        submit_button = Button(delete_window, text="Submit", command=lambda: self.submit_delete(id_entry.get()))
        submit_button.pack()

    def submit_delete(self, id):
        if not id:
            messagebox.showerror("Error", "ID is required!")
        else:
            result = self.database.delete_patient(id)
            if result:
                messagebox.showinfo("Success", "Patient successfully deleted!")
            else:
                messagebox.showerror("Error", "Patient not found!")

    def update_patient(self):
        # create a new window to update patient data
        update_window = Toplevel(self.parent)
        update_window.title("Update Patient")
        update_window.geometry("300x300")

        # create the form widgets here...
        id_label = Label(update_window, text="ID:")
        id_label.pack()

        id_entry = Entry(update_window, textvariable=self.id_var)
        id_entry.pack()

        name_label = Label(update_window, text="Name:")
        name_label.pack()

        name_entry = Entry(update_window, textvariable=self.name_var)
        name_entry.pack()

        age_label = Label(update_window, text="Age:")
        age_label.pack()

        age_entry = Entry(update_window, textvariable=self.age_var)
        age_entry.pack()

        gender_label = Label(update_window, text="Gender:")
        gender_label.pack()

        gender_male_radio = Radiobutton(update_window, text="Male", variable=self.gender_var, value="Male")
        gender_male_radio.pack()

        gender_female_radio = Radiobutton(update_window, text="Female", variable=self.gender_var, value="Female")
        gender_female_radio.pack()

        address_label = Label(update_window, text="Address")
        address_label.pack()

        address_entry = Entry(update_window, textvariable=self.address_var)
        address_entry.pack()

        submit_button = Button(update_window, text="Submit",
                               command=lambda: self.submit_update_form(int(self.id_var.get())))
        submit_button.pack()

    def submit_update_form(self, id):
        name = self.name_var.get()
        age = self.age_var.get()
        gender = self.gender_var.get()
        address = self.address_var.get()

        # check if all fields are filled out
        if not all([name, age, gender, address]):
            messagebox.showerror("Error", "All fields are required!")
        else:
            # update the patient record in the database
            rows_affected = self.database.update_patient(id, name, age, gender, address)

            # show a success or error message
            if rows_affected is not None and rows_affected > 0:
                messagebox.showinfo("Success", "Patient record updated!")
                # clear the form fields after successful update
                self.name_var.set("")
                self.age_var.set("")
                self.gender_var.set("Male")
                self.address_var.set("")
            else:
                messagebox.showerror("Error", "Patient record could not be updated!")
