import tkinter as tk
from tkinter import messagebox
from Quambot.src.components.face import FaceRecognition
import sqlite3
from Quambot.src.components.utils import hash_password
from Quambot.src.screens.account_creation import AccountCreationScreen
from Quambot.src.databases.userdatabase import UserDatabase
import customtkinter
from PIL import Image, ImageTk


class LoginScreen(customtkinter.CTkFrame):
    def __init__(self, parent, on_login):
        super().__init__(parent)
        self.create_account_screen = None
        self.on_login = on_login

        # Load the background image
        bg_image = Image.open("assets/images/pattern.png")
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        # Create a label to display the background image
        self.bg_label = customtkinter.CTkLabel(self, image=self.bg_photo)
        self.bg_label.place(x=0, y=0, relwidth=1, relheight=1)

        self.username_label = customtkinter.CTkLabel(self, text="Username:")
        self.username_label.pack()

        self.username_entry = customtkinter.CTkEntry(self)
        self.username_entry.pack()

        self.password_label = customtkinter.CTkLabel(self, text="Password:")
        self.password_label.pack()

        self.password_entry = customtkinter.CTkEntry(self, show="*")
        self.password_entry.pack()

        self.login_button = customtkinter.CTkButton(self, text="Login", command=self.login)
        self.login_button.pack()
        '''''''''
        self.face_id_button = customtkinter.CTkButton(self, text="Face ID", command=self.face_id_login)
        self.face_id_button.pack()

        self.face_recognition = FaceRecognition()

        
        self.fingerprint_button = customtkinter.CTkButton(self, text="Fingerprint", command=self.fingerprint_login)
        self.fingerprint_button.pack()

        self.fingerprint_recognition = FingerprintRecognition()
        
        '''''''''

        self.create_account_button = customtkinter.CTkButton(self, text="Create Account", command=self.create_account)
        self.create_account_button.pack()

        self.bypass_button = customtkinter.CTkButton(self, text="Bypass", command=self.bypass)
        self.bypass_button.pack()

        self.conn = sqlite3.connect("src/databases/users.db")

    '''''
    def face_id_login(self):
        self.face_recognition.run_recognition()
        if self.face_recognition.get_authentication_status():
            self.on_login()
        else:
            messagebox.showerror("Authentication Error", "Face ID authentication failed.")

  
    def fingerprint_login(self):
        self.fingerprint_recognition.run_recognition()
        if self.fingerprint_recognition.get_authentication_status():
            self.on_login()
        else:
            messagebox.showerror("Authentication Error", "Fingerprint authentication failed.")

    '''''

    def create_account(self):
        # Open the account creation screen as a new window
        self.create_account_screen = AccountCreationScreen(self, self.conn, self.on_login)
        self.create_account_screen.attributes("-topmost", True)

    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        if not username or not password:
            messagebox.showerror("Login Error", "Username and password cannot be empty.")
            return

        # Get the user from the database by username
        user_db = UserDatabase(self.conn)
        user = user_db.get_user_by_username(username)

        if user:
            # Hash the entered password and compare it with the stored hash
            hashed_password = hash_password(password)
            if hashed_password == user[2]:  # User[2] is the hashed password stored in the database
                messagebox.showinfo("Login Success", "Login successful!")
                self.on_login()
            else:
                messagebox.showerror("Login Error", "Invalid password.")
                self.password_entry.delete(0, tk.END)
        else:
            messagebox.showerror("Login Error", "Invalid username.")
            self.password_entry.delete(0, tk.END)

    def bypass(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        # check if username and password are valid
        if username == "" and password == "":
            messagebox.showinfo("Success", "Success!!")
            self.on_login()
        else:
            self.password_entry.delete(0, tk.END)
