import customtkinter
from PIL import Image, ImageTk


class Dashboard(customtkinter.CTkFrame):  # Inherit from customtkinter.CTkFrame
    def __init__(self, parent, register_patient_callback, view_patients_callback, logout_callback):
        super().__init__(parent)
        self.register_patient_callback = register_patient_callback
        self.view_patients_callback = view_patients_callback
        self.logout_callback = logout_callback

        # Load the background image
        bg_image = Image.open("assets/images/pattern.png")
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        # Create a label to display the background image
        self.bg_label = customtkinter.CTkLabel(self, image=self.bg_photo)
        self.bg_label.place(x=0, y=0, relwidth=1, relheight=1)

        self.register_patient_button = customtkinter.CTkButton(self, text="Register Patient",
                                                               command=self.register_patient_callback, corner_radius=6)
        self.register_patient_button.pack()

        self.view_patients_button = customtkinter.CTkButton(self, text="View Patients",
                                                            command=self.view_patients_callback, corner_radius=6)
        self.view_patients_button.pack()

        self.logout_button = customtkinter.CTkButton(self, text="Logout", command=self.logout_callback, corner_radius=6)
        self.logout_button.pack(side="left", padx=50, pady=100)
