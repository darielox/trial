import sqlite3

class Database:
    def __init__(self):
        self.conn = sqlite3.connect("src/databases/patients.db")
        self.create_table()
        self.cur = self.conn.cursor()

    def __del__(self):
        self.conn.close()

    def create_table(self):
        cursor = self.conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS patients (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                age INTEGER NOT NULL,
                gender TEXT NOT NULL,
                address TEXT NOT NULL
            );
        """)
        self.conn.commit()

    def get_selected_patient_id(self, id):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM patients WHERE id=?", (id,))
        patient = cursor.fetchone()
        if patient:
            return patient[0]
        else:
            return None

    def insert_patient(self, patient_data):
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO patients(name, age, gender, address) VALUES (?, ?, ?, ?);
        """, (patient_data["name"], patient_data["age"], patient_data["gender"], patient_data["address"]))
        self.conn.commit()

    def get_all_patients(self):
        cursor = self.cur
        cursor.execute("""
            SELECT * FROM patients;
        """)
        patients_data = cursor.fetchall()
        return [{"id": row[0], "name": row[1], "age": row[2], "gender": row[3], "address": row[4]} for row in
                patients_data]

    def update_patient(self, patient_id, name, age, gender, address):
        try:
            cursor = self.conn.cursor()
            cursor.execute("""
                UPDATE patients SET name=?, age=?, gender=?, address=? WHERE id=?;
            """, (name, age, gender, address, patient_id))
            self.conn.commit()
            return True
        except Exception as e:
            print("Error updating patient record:", e)
            return False

    def delete_patient(self, patient_id):
        conn = sqlite3.connect("patients.db")
        cursor = conn.cursor()
        cursor.execute("""
            DELETE FROM patients WHERE id=?;
        """, (patient_id,))
        conn.commit()
        if cursor.rowcount == 1:
            return True
        else:
            return False


