from Quambot.src.components.utils import hash_password

class UserDatabase:
    def __init__(self, conn):
        self.conn = conn
        self.create_table()

    def create_table(self):
        cursor = self.conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                username TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL
            );
        """)
        self.conn.commit()

    def insert_user(self, username, password):
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO users (username, password) VALUES (?, ?);
        """, (username, password))
        self.conn.commit()

    def get_user_by_username(self, username):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username=?", (username,))
        user = cursor.fetchone()
        return user

    def update_user_password(self, username, password):
        hashed_password = hash_password(password)
        cursor = self.conn.cursor()
        cursor.execute("UPDATE users SET password=? WHERE username=?", (hashed_password, username))
        self.conn.commit()
