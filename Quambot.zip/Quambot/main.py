from src.app.app import App

if __name__ == "__main__":
    app = App()
    app.login_screen.pack(fill="both", expand=True)
    app.mainloop()
